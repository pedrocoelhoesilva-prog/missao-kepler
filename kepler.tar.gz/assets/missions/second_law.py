def calculate_swept_area(points):
    if len(points) < 2:
        return 0.0

    cross_sum = 0.0

    for i in range(len(points) - 1):
        x1, y1 = points[i]
        x2, y2 = points[i + 1]

        cross_sum += x1 * y2 - x2 * y1

    return abs(cross_sum) / 2