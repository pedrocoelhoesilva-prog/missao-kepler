import math

def calculate_foci(orbit):
    if orbit["type"] not in ("ELIPTICA", "HIPERBOLICA"):
        return None

    a = abs(orbit["a"])
    ex = orbit["ex"]
    ey = orbit["ey"]

    focus_x = -2 * a * ex
    focus_y = -2 * a * ey

    return focus_x, focus_y

def calculate_ellipse_geometry(orbit):
    if orbit["type"] != "ELIPTICA":
        return None

    a = orbit["a"]
    e = orbit["eccentricity"]
    ex = orbit["ex"]
    ey = orbit["ey"]

    # Para uma elipse quase circular, escolhemos
    # uma direção visual padrão.
    if e > 0.00001:
        major_x = ex / e
        major_y = ey / e
    else:
        major_x = 1.0
        major_y = 0.0

    # Direção perpendicular ao eixo maior
    minor_x = -major_y
    minor_y = major_x

    # Semieixo menor
    b = a * math.sqrt(max(0, 1 - e * e))

    # Distância focal
    c = a * e

    # Centro da elipse
    center_x = -c * major_x
    center_y = -c * major_y

    # Periélio
    perihelion_distance = a * (1 - e)
    perihelion_x = perihelion_distance * major_x
    perihelion_y = perihelion_distance * major_y

    # Afélio
    aphelion_distance = a * (1 + e)
    aphelion_x = -aphelion_distance * major_x
    aphelion_y = -aphelion_distance * major_y

    # Extremos do eixo menor
    minor_top_x = center_x + b * minor_x
    minor_top_y = center_y + b * minor_y

    minor_bottom_x = center_x - b * minor_x
    minor_bottom_y = center_y - b * minor_y

    # Segundo foco
    focus2_x = center_x - c * major_x
    focus2_y = center_y - c * major_y

    return {
        "center": (center_x, center_y),
        "perihelion": (perihelion_x, perihelion_y),
        "aphelion": (aphelion_x, aphelion_y),
        "minor_top": (minor_top_x, minor_top_y),
        "minor_bottom": (minor_bottom_x, minor_bottom_y),
        "focus1": (0, 0),
        "focus2": (focus2_x, focus2_y),
        "a": a,
        "b": b,
        "c": c,
        "major_direction": (major_x, major_y)
    }