# Dimensões da janela
WIDTH = 1000
HEIGHT = 700
FPS = 60

# Física
G = 5000.0
CENTRAL_MASS = 1000.0
MU = G * CENTRAL_MASS

# Corpo central
SUN_RADIUS = 20

# Centro visual da tela
CENTER_X = WIDTH / 2
CENTER_Y = HEIGHT / 2

# Cores
BACKGROUND = (10, 12, 28)
STAR_COLOR = (255, 210, 80)
SHIP_COLOR = (100, 200, 255)

ORBIT_COLOR = (80, 110, 160)
PREDICTED_ORBIT_COLOR = (70, 80, 110)

TEXT_COLOR = (230, 230, 240)
WARNING_COLOR = (255, 120, 120)

# Precisão da simulação
MAX_PHYSICS_STEP = 1 / 240