import pygame


class Slider:
    def __init__(
        self, x, y, width, minimum, maximum, value, label,
        unit="", decimals=2
    ):
        self.x, self.y, self.width = x, y, width
        self.minimum, self.maximum = minimum, maximum
        self.value, self.label = value, label
        self.unit, self.decimals = unit, decimals

        self.dragging = False
        self.editing = False
        self.input_text = ""

        self.track_height = 6
        self.handle_radius = 10

        self.input_rect = pygame.Rect(
            x + width + 15, y - 15, 130, 30
        )

    def get_handle_x(self):
        percentage = (self.value - self.minimum) / (self.maximum - self.minimum)
        return self.x + percentage * self.width

    def commit_input(self):
        try:
            new_value = float(self.input_text.replace(",", "."))
            self.value = max(self.minimum, min(self.maximum, new_value))
        except ValueError:
            pass

        self.editing = False
        self.input_text = ""
        pygame.key.stop_text_input()

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.input_rect.collidepoint(event.pos):
                self.editing = True
                self.dragging = False
                self.input_text = ""
                pygame.key.start_text_input()
                return True

            if self.editing:
                self.commit_input()

        if self.editing:
            if event.type == pygame.TEXTINPUT:
                allowed = "0123456789.,-"
                self.input_text += "".join(
                    char for char in event.text if char in allowed
                )
                return True

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    self.commit_input()
                elif event.key == pygame.K_ESCAPE:
                    self.editing = False
                    self.input_text = ""
                    pygame.key.stop_text_input()
                elif event.key == pygame.K_BACKSPACE:
                    self.input_text = self.input_text[:-1]

                return True

        return False

    def update(self, mouse_position, mouse_pressed):
        if self.editing:
            return

        mouse_x, mouse_y = mouse_position
        handle_x = self.get_handle_x()

        distance = (
            (mouse_x - handle_x) ** 2
            + (mouse_y - self.y) ** 2
        ) ** 0.5

        if mouse_pressed and distance < 15:
            self.dragging = True
        elif not mouse_pressed:
            self.dragging = False

        if self.dragging:
            percentage = max(0, min(1, (mouse_x - self.x) / self.width))
            self.value = self.minimum + percentage * (self.maximum - self.minimum)

    def draw(self, surface, font, text_color=(230, 230, 240)):
        handle_x = self.get_handle_x()

        pygame.draw.line(
            surface, (100, 110, 140),
            (self.x, self.y), (self.x + self.width, self.y),
            self.track_height
        )

        pygame.draw.line(
            surface, (120, 190, 255),
            (self.x, self.y), (handle_x, self.y),
            self.track_height
        )

        pygame.draw.circle(
            surface, (220, 230, 255),
            (int(handle_x), self.y), self.handle_radius
        )

        label_surface = font.render(self.label, True, text_color)
        surface.blit(label_surface, (self.x, self.y - 35))

        box_color = (120, 190, 255) if self.editing else (100, 110, 140)

        pygame.draw.rect(
            surface, (25, 30, 50), self.input_rect, border_radius=5
        )
        pygame.draw.rect(
            surface, box_color, self.input_rect, 1, border_radius=5
        )

        if self.editing:
            displayed_value = self.input_text
        else:
            displayed_value = f"{self.value:.{self.decimals}f} {self.unit}"

        value_surface = font.render(displayed_value, True, text_color)
        value_rect = value_surface.get_rect(center=self.input_rect.center)
        surface.blit(value_surface, value_rect)