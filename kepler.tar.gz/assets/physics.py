import math

from settings import MU, SUN_RADIUS


class SpaceObject:
    def __init__(self, x, y, vx, vy, mass=1.0, mu=MU):
        self.x = float(x)
        self.y = float(y)

        self.vx = float(vx)
        self.vy = float(vy)

        self.mass = mass
        self.mu = mu

        self.trail = []
        self.crashed = False

    def acceleration(self, x, y):
        distance_sq = x * x + y * y
        distance = math.sqrt(distance_sq)

        if distance < 0.001:
            return 0.0, 0.0

        factor = -self.mu / (distance_sq * distance)

        return factor * x, factor * y

    def update(self, dt):
        if self.crashed:
            return

        ax1, ay1 = self.acceleration(self.x, self.y)

        new_x = self.x + self.vx * dt + 0.5 * ax1 * dt * dt
        new_y = self.y + self.vy * dt + 0.5 * ay1 * dt * dt

        ax2, ay2 = self.acceleration(new_x, new_y)

        self.vx += 0.5 * (ax1 + ax2) * dt
        self.vy += 0.5 * (ay1 + ay2) * dt

        self.x = new_x
        self.y = new_y

        distance = math.hypot(self.x, self.y)

        if distance <= SUN_RADIUS:
            self.crashed = True

            if distance > 0:
                self.x *= SUN_RADIUS / distance
                self.y *= SUN_RADIUS / distance

        self.trail.append((self.x, self.y))

        if len(self.trail) > 3000:
            self.trail.pop(0)