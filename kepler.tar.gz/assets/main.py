import pygame
import math
import asyncio

from ui import Slider
from settings import *
from physics import SpaceObject
from missions.second_law import calculate_swept_area
from missions.first_law import calculate_foci
from missions.first_law import calculate_ellipse_geometry

pygame.init()

# JANELA E RESOLUÇÃO LÓGICA

WINDOWED_SIZE = (WIDTH, HEIGHT)

fullscreen = False

display = pygame.display.set_mode((WIDTH, HEIGHT))
screen = display

pygame.display.set_caption("Missão Kepler")
clock = pygame.time.Clock()

font = pygame.font.SysFont("Arial", 20)
small_font = pygame.font.SysFont("Arial", 16)

def update_layout():
    global reset_button_rect

    panel_x = WIDTH - 350

    slider_positions = [
        HEIGHT - 280,
        HEIGHT - 225,
        HEIGHT - 170,
        HEIGHT - 115,
        HEIGHT - 60
    ]

    for slider, y in zip(sliders, slider_positions):
        slider.x = panel_x
        slider.y = y

        slider.input_rect.x = panel_x + slider.width + 15
        slider.input_rect.y = y - 15

    reset_button_rect = pygame.Rect(
        panel_x,
        HEIGHT - 35,
        305,
        25
    )

def toggle_fullscreen():
    global display, screen, fullscreen
    global WIDTH, HEIGHT, CENTER_X, CENTER_Y

    if fullscreen:
        display = pygame.display.set_mode(WINDOWED_SIZE)
        fullscreen = False
    else:
        display = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        fullscreen = True

    screen = display

    WIDTH, HEIGHT = display.get_size()

    CENTER_X = WIDTH / 2
    CENTER_Y = HEIGHT / 2

    update_layout()

# CONFIGURAÇÕES

initial_radius = 180.0
initial_speed = 160.0

central_mass = CENTRAL_MASS
current_mu = G * central_mass

zoom = 1.0
MIN_ZOOM, MAX_ZOOM = 0.05, 5.0
follow_ship = False
geometry_mode = False

simulation_speed = 1.0
MIN_SIMULATION_SPEED, MAX_SIMULATION_SPEED = 0.1, 100.0


# SLIDERS

speed_slider = Slider(
    650, 420, 160, 0, 300, initial_speed,
    "Velocidade inicial", "m/s", 2
)

simulation_slider = Slider(
    650, 475, 160, 0.1, 100, simulation_speed,
    "Velocidade da simulacao", "x", 2
)

zoom_slider = Slider(
    650, 530, 160, 0.05, 5, zoom,
    "Zoom", "x", 3
)

mass_slider = Slider(
    650, 585, 160, 100, 3000, central_mass,
    "Massa central", "u.m.", 1
)

radius_slider = Slider(
    650, 640, 160, SUN_RADIUS + 10, 400, initial_radius,
    "Distancia inicial", "u.d.", 2
)

sliders = [
    speed_slider,
    simulation_slider,
    zoom_slider,
    mass_slider,
    radius_slider
]

reset_button_rect = pygame.Rect(650, 670, 305, 25)

# FERRAMENTA DE MEDIÇÃO DE ÁREAS

measurement_input_rect = pygame.Rect(20, 180, 100, 32)
measurement_button_rect = pygame.Rect(132, 180, 205, 32)
orbital_record_button_rect = pygame.Rect(20, 180, 205, 32)
decimal_input_rect = pygame.Rect(390, 180, 70, 30)

measurement_input_text = "1.0"
measurement_input_active = False

measurements = []
active_measurement = None
orbital_records = []
third_law_status = "Nenhuma órbita registrada."
decimal_places = 2
decimal_input_text = "2"
decimal_input_active = False

measurement_elapsed = 0.0
measurement_remaining = 0.0

measurement_status = "Informe o intervalo e inicie a primeira medição."
measurement_error = False

# FUNÇÕES BÁSICAS

def create_ship():
    return SpaceObject(
        initial_radius, 0,
        0, -initial_speed,
        mu=current_mu
    )

def reset_settings():
    global initial_radius, initial_speed
    global simulation_speed, zoom
    global central_mass, current_mu

    initial_radius = 180.0
    initial_speed = 160.0
    simulation_speed = 1.0
    zoom = 1.0
    central_mass = CENTRAL_MASS

    current_mu = G * central_mass

    speed_slider.value = initial_speed
    simulation_slider.value = simulation_speed
    zoom_slider.value = zoom
    mass_slider.value = central_mass
    radius_slider.value = initial_radius


def draw_text(text, x, y, color=TEXT_COLOR, small=False):
    selected_font = small_font if small else font
    surface = selected_font.render(str(text), True, color)
    screen.blit(surface, (x, y))

# SELEÇÃO DE MISSÕES

MISSION_OPTIONS = [
    (
        "first_law",
        "MISSÃO 01 — PRIMEIRA LEI",
        "Investigue a geometria das órbitas elípticas."
    ),
    (
        "second_law",
        "MISSÃO 02 — SEGUNDA LEI",
        "Investigue as áreas varridas pela sonda."
    ),
    (
        "third_law",
        "MISSÃO 03 — TERCEIRA LEI",
        "Compare períodos e tamanhos de órbitas."
    )
]

FIRST_LAW_STEPS = [
    {
        "title": "Geometria orbital",
        "question": "Qual é o formato geométrico de uma órbita fechada?",
        "options": [
            "Uma circunferência perfeita",
            "Uma elipse",
            "Uma parábola",
            "Uma hipérbole"
        ],
        "correct": 1,
        "feedback_correct": (
            "Uma órbita elíptica possui formato de elipse. "
            "Observe como sua excentricidade altera esse formato."
        ),
        "feedback_wrong": (
            "Observe novamente a trajetória do planeta e tente "
            "identificar a curva que ela representa."
        )
    },
    {
        "title": "Os focos da elipse",
        "question": "Em uma órbita elíptica ao redor do Sol, onde ele está localizado?",
        "options": [
            "Exatamente no centro da elipse",
            "Em um dos focos da elipse",
            "Sempre na extremidade mais distante",
            "Fora do plano da órbita"
        ],
        "correct": 1,
        "feedback_correct": (
            "Pela primeira lei de Kepler, o Sol ocupa um dos focos "
            "da órbita elíptica."
        ),
        "feedback_wrong": (
            "Observe a posição do Sol em relação ao centro e aos "
            "dois focos da elipse."
        )
    },
    {
        "title": "Excentricidade",
        "question": "O que acontece com uma elipse quando sua excentricidade aumenta?",
        "options": [
            "Ela se torna mais circular",
            "Ela se torna mais alongada",
            "Seu tamanho necessariamente aumenta",
            "Seu centro se desloca para um dos focos"
        ],
        "correct": 1,
        "feedback_correct": (
            "Quanto maior a excentricidade, mais alongada é a elipse. "
            "Uma circunferência possui excentricidade zero."
        ),
        "feedback_wrong": (
            "Compare elipses com diferentes valores de excentricidade "
            "na simulação."
        )
    }
]

def get_mission_button_rects():
    button_width = 560
    button_height = 90
    gap = 15

    total_height = (
        len(MISSION_OPTIONS) * button_height
        + (len(MISSION_OPTIONS) - 1) * gap
    )

    start_y = (HEIGHT - total_height) // 2 + 35
    start_x = (WIDTH - button_width) // 2

    buttons = {}

    for i, option in enumerate(MISSION_OPTIONS):
        mission_id = option[0]

        buttons[mission_id] = pygame.Rect(
            start_x,
            start_y + i * (button_height + gap),
            button_width,
            button_height
        )

    return buttons

def draw_mission_menu():
    screen.fill(BACKGROUND)

    draw_text(
        "MISSÃO KEPLER",
        WIDTH // 2 - 105,
        75
    )

    draw_text(
        "CENTRAL DE OPERAÇÕES CIENTÍFICAS",
        WIDTH // 2 - 170,
        110,
        small=True
    )

    buttons = get_mission_button_rects()

    for option in MISSION_OPTIONS:
        mission_id, title, description = option
        rect = buttons[mission_id]

        pygame.draw.rect(
            screen,
            (25, 35, 60),
            rect,
            border_radius=8
        )

        pygame.draw.rect(
            screen,
            (90, 130, 190),
            rect,
            2,
            border_radius=8
        )

        draw_text(
            title,
            rect.x + 20,
            rect.y + 17
        )

        draw_text(
            description,
            rect.x + 20,
            rect.y + 52,
            small=True
        )

    pygame.display.flip()

def get_back_button_rect():
    return pygame.Rect(WIDTH - 150, 15, 130, 32)


def draw_back_button():
    rect = get_back_button_rect()

    pygame.draw.rect(
        screen,
        (35, 45, 70),
        rect,
        border_radius=5
    )

    pygame.draw.rect(
        screen,
        (120, 190, 255),
        rect,
        1,
        border_radius=5
    )

    text = small_font.render(
        "VOLTAR AO MENU",
        True,
        TEXT_COLOR
    )

    text_rect = text.get_rect(center=rect.center)
    screen.blit(text, text_rect)

def answer_first_law_question(answer):
    global first_law_step
    global first_law_answer
    global first_law_feedback
    global first_law_completed

    if first_law_completed:
        return

    step = FIRST_LAW_STEPS[first_law_step]
    first_law_answer = answer

    if answer == step["correct"]:
        first_law_feedback = step["feedback_correct"]
    else:
        first_law_feedback = step["feedback_wrong"]

def advance_first_law_step():
    global first_law_step
    global first_law_answer
    global first_law_feedback
    global first_law_completed

    step = FIRST_LAW_STEPS[first_law_step]

    if first_law_answer != step["correct"]:
        return

    if first_law_step == len(FIRST_LAW_STEPS) - 1:
        first_law_completed = True
    else:
        first_law_step += 1

    first_law_answer = None
    first_law_feedback = ""

def draw_wrapped_text(text, x, y, max_width, color=TEXT_COLOR, small=False):
    selected_font = small_font if small else font
    words = str(text).split()
    lines = []
    current_line = ""

    for word in words:
        test_line = f"{current_line} {word}".strip()

        if selected_font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word

    if current_line:
        lines.append(current_line)

    for i, line in enumerate(lines):
        draw_text(line, x, y + i * selected_font.get_linesize(), color, small)

def draw_first_law_question():
    if current_mission != "first_law":
        return

    if first_law_completed:
        panel = pygame.Rect(20, 145, 430, 180)

        pygame.draw.rect(screen, (20, 28, 48), panel, border_radius=8)
        pygame.draw.rect(screen, (80, 120, 170), panel, 2, border_radius=8)

        draw_text("MISSÃO CONCLUÍDA", panel.x + 15, panel.y + 20)

        draw_wrapped_text(
            "Você compreendeu os fundamentos geométricos da primeira lei de Kepler.",
            panel.x + 15,
            panel.y + 65,
            panel.width - 30,
            small=True
        )

        return

    step = FIRST_LAW_STEPS[first_law_step]

    panel = pygame.Rect(20, 145, 430, 340)

    pygame.draw.rect(screen, (20, 28, 48), panel, border_radius=8)
    pygame.draw.rect(screen, (80, 120, 170), panel, 2, border_radius=8)

    draw_text(
        f"ETAPA {first_law_step + 1}/{len(FIRST_LAW_STEPS)}",
        panel.x + 15,
        panel.y + 12,
        small=True
    )

    draw_text(step["title"], panel.x + 15, panel.y + 40)

    draw_wrapped_text(
        step["question"],
        panel.x + 15,
        panel.y + 80,
        panel.width - 30,
        small=True
    )

    option_rects = []

    for i, option in enumerate(step["options"]):
        rect = pygame.Rect(
            panel.x + 15,
            panel.y + 120 + i * 38,
            panel.width - 30,
            32
        )
        option_rects.append(rect)

        color = (55, 75, 110)
        if first_law_answer == i:
            color = (90, 120, 170)

        pygame.draw.rect(screen, color, rect, border_radius=5)

        draw_text(
            f"{chr(65 + i)}. {option}",
            rect.x + 10,
            rect.y + 7,
            small=True
        )

    if first_law_feedback:
        draw_wrapped_text(
            first_law_feedback,
            panel.x + 15,
            panel.y + 280,
            panel.width - 30,
            small=True
        )

    continue_rect = None

    if first_law_answer == step["correct"]:
        continue_rect = pygame.Rect(
            panel.right - 125,
            panel.bottom + 10,
            110,
            32
        )

        pygame.draw.rect(
            screen,
            (55, 130, 90),
            continue_rect,
            border_radius=5
        )

        draw_text(
            "Continuar",
            continue_rect.x + 15,
            continue_rect.y + 7,
            small=True
        )

    return option_rects, continue_rect

def world_to_screen(x, y, camera_x, camera_y):
    sx = CENTER_X + (x - camera_x) * zoom
    sy = CENTER_Y + (y - camera_y) * zoom
    return int(sx), int(sy)


# ELEMENTOS ORBITAIS

def calculate_orbit(x, y, vx, vy):
    r = math.hypot(x, y)
    v_squared = vx**2 + vy**2

    if v_squared < 0.000001:
        return {
            "type": "QUEDA RADIAL",
            "eccentricity": 1.0,
            "ex": 0.0,
            "ey": 0.0,
            "p": 0.0,
            "h": 0.0,
            "energy": -current_mu / r,
            "a": r / 2,
            "period": None
        }

    energy = v_squared / 2 - current_mu / r
    h = x * vy - y * vx

    ex = vy * h / current_mu - x / r
    ey = -vx * h / current_mu - y / r

    eccentricity = math.hypot(ex, ey)
    p = h**2 / current_mu

    result = {
        "energy": energy,
        "eccentricity": eccentricity,
        "ex": ex,
        "ey": ey,
        "p": p,
        "h": h
    }

    if energy < -0.00001:
        a = -current_mu / (2 * energy)

        result.update({
            "type": "ELIPTICA",
            "a": a,
            "period": 2 * math.pi * math.sqrt(a**3 / current_mu)
        })

    elif abs(energy) <= 0.00001:
        result.update({
            "type": "PARABOLICA",
            "a": None,
            "period": None
        })

    else:
        result.update({
            "type": "HIPERBOLICA",
            "a": -current_mu / (2 * energy),
            "period": None
        })

    return result

def generate_predicted_orbit(orbit):
    if orbit["type"] == "QUEDA RADIAL":
        return [(initial_radius, 0), (0, 0)]

    e = orbit["eccentricity"]
    p = orbit["p"]
    ex, ey = orbit["ex"], orbit["ey"]

    periapsis_angle = math.atan2(ey, ex) if e > 0.00001 else 0
    orbit_type = orbit["type"]

    if orbit_type == "ELIPTICA":
        max_angle, steps = math.pi, 500
        start_angle = 0

    elif orbit_type == "PARABOLICA":
        max_angle, steps = 2.4, 400
        start_angle = -max_angle

    elif orbit_type == "HIPERBOLICA":
        max_angle = math.acos(-1 / e) * 0.98
        steps = 500
        start_angle = -max_angle

    else:
        return []

    points = []

    for i in range(steps + 1):
        if orbit_type == "ELIPTICA":
            anomaly = 2 * math.pi * i / steps
        else:
            anomaly = start_angle + 2 * max_angle * i / steps

        denominator = 1 + e * math.cos(anomaly)

        if denominator <= 0:
            continue

        r = p / denominator

        if r > 20000:
            continue

        angle = periapsis_angle + anomaly
        points.append((r * math.cos(angle), r * math.sin(angle)))

    return points

def draw_ellipse_geometry(orbit, camera_x, camera_y):
    geometry = calculate_ellipse_geometry(orbit)

    if geometry is None:
        return

    center = geometry["center"]
    perihelion = geometry["perihelion"]
    aphelion = geometry["aphelion"]

    minor_top = geometry["minor_top"]
    minor_bottom = geometry["minor_bottom"]

    focus1 = geometry["focus1"]
    focus2 = geometry["focus2"]

    a = geometry["a"]
    b = geometry["b"]
    c = geometry["c"]

    # Conversão para coordenadas da tela

    center_screen = world_to_screen(
        *center, camera_x, camera_y
    )

    perihelion_screen = world_to_screen(
        *perihelion, camera_x, camera_y
    )

    aphelion_screen = world_to_screen(
        *aphelion, camera_x, camera_y
    )

    minor_top_screen = world_to_screen(
        *minor_top, camera_x, camera_y
    )

    minor_bottom_screen = world_to_screen(
        *minor_bottom, camera_x, camera_y
    )

    focus1_screen = world_to_screen(
        *focus1, camera_x, camera_y
    )

    focus2_screen = world_to_screen(
        *focus2, camera_x, camera_y
    )

    # CORES

    axis_color = (90, 120, 160)
    major_color = (120, 180, 255)
    minor_color = (120, 220, 190)

    center_color = (240, 240, 240)
    perihelion_color = (255, 180, 80)
    aphelion_color = (180, 130, 255)

    focal_color = (255, 120, 180)

    # EIXO MAIOR COMPLETO
    pygame.draw.line(
        screen,
        axis_color,
        aphelion_screen,
        perihelion_screen,
        1
    )

    # EIXO MENOR COMPLETO
    pygame.draw.line(
        screen,
        axis_color,
        minor_top_screen,
        minor_bottom_screen,
        1
    )

    # SEMIEIXO MAIOR "a"
    pygame.draw.line(
        screen,
        major_color,
        center_screen,
        perihelion_screen,
        2
    )

    # SEMIEIXO MENOR "b"
    pygame.draw.line(
        screen,
        minor_color,
        center_screen,
        minor_top_screen,
        2
    )

    # DISTÂNCIA FOCAL "c"
    pygame.draw.line(
        screen,
        focal_color,
        center_screen,
        focus1_screen,
        2
    )

    # CENTRO

    pygame.draw.circle(
        screen,
        center_color,
        center_screen,
        5
    )

    draw_text(
        "Centro",
        center_screen[0] + 8,
        center_screen[1] + 5,
        center_color,
        small=True
    )

    # PERIÉLIO

    pygame.draw.circle(
        screen,
        perihelion_color,
        perihelion_screen,
        5
    )

    draw_text(
        "Perielio",
        perihelion_screen[0] + 8,
        perihelion_screen[1] + 5,
        perihelion_color,
        small=True
    )

    # AFÉLIO

    pygame.draw.circle(
        screen,
        aphelion_color,
        aphelion_screen,
        5
    )

    draw_text(
        "Afelio",
        aphelion_screen[0] + 8,
        aphelion_screen[1] + 5,
        aphelion_color,
        small=True
    )

    # RÓTULO DO SEMIEIXO MAIOR

    a_x = (
        center_screen[0]
        + perihelion_screen[0]
    ) // 2

    a_y = (
        center_screen[1]
        + perihelion_screen[1]
    ) // 2

    draw_text(
        f"a = {a:.1f}",
        a_x + 5,
        a_y + 5,
        major_color,
        small=True
    )

    # RÓTULO DO SEMIEIXO MENOR

    b_x = (
        center_screen[0]
        + minor_top_screen[0]
    ) // 2

    b_y = (
        center_screen[1]
        + minor_top_screen[1]
    ) // 2

    draw_text(
        f"b = {b:.1f}",
        b_x + 5,
        b_y + 5,
        minor_color,
        small=True
    )

    # RÓTULO DA DISTÂNCIA FOCAL

    c_x = (
        center_screen[0]
        + focus1_screen[0]
    ) // 2

    c_y = (
        center_screen[1]
        + focus1_screen[1]
    ) // 2

    draw_text(
        f"c = {c:.1f}",
        c_x + 5,
        c_y - 18,
        focal_color,
        small=True
    )

def draw_foci(orbit, camera_x, camera_y):
    focus_position = world_to_screen(
        0, 0, camera_x, camera_y
    )

    # Primeiro foco: posição do Sol
    pygame.draw.circle(
        screen, (100, 255, 150),
        focus_position, 5, 2
    )

    draw_text(
        "F1", focus_position[0] + 10,
        focus_position[1] + 5,
        (100, 255, 150), small=True
    )

    second_focus = calculate_foci(orbit)

    if second_focus is None:
        return

    focus_position = world_to_screen(
        *second_focus, camera_x, camera_y
    )

    if 0 <= focus_position[0] <= WIDTH and 0 <= focus_position[1] <= HEIGHT:
        pygame.draw.circle(
            screen, (255, 120, 180),
            focus_position, 5, 2
        )

        draw_text(
            "F2", focus_position[0] + 10,
            focus_position[1] + 5,
            (255, 120, 180), small=True
        )

# DESENHO DA ÓRBITA PREVISTA

def draw_dashed_orbit(points, camera_x, camera_y):
    if len(points) < 2:
        return

    dash_size = 4

    for i in range(0, len(points) - 1, dash_size * 2):
        end = min(i + dash_size, len(points) - 1)

        start_point = world_to_screen(*points[i], camera_x, camera_y)
        end_point = world_to_screen(*points[end], camera_x, camera_y)

        pygame.draw.line(screen, PREDICTED_ORBIT_COLOR, start_point, end_point, 1)

def start_area_measurement():
    global active_measurement
    global measurement_elapsed, measurement_remaining
    global paused, measurement_status, measurement_error
    global measurement_input_text

    if active_measurement is not None:
        return

    # Se já existem duas medições, o botão limpa os resultados.
    if len(measurements) >= 2:
        measurements.clear()
        measurement_status = "Medições apagadas. Inicie uma nova comparação."
        measurement_error = False
        return

    # A segunda medição usa obrigatoriamente o mesmo intervalo.
    if len(measurements) == 1:
        duration = measurements[0]["duration"]
        measurement_input_text = str(duration)
    else:
        try:
            duration = float(measurement_input_text.replace(",", "."))
        except ValueError:
            measurement_status = "Intervalo inválido. Digite um número."
            measurement_error = True
            return

    if not math.isfinite(duration) or duration <= 0 or duration > 10000:
        measurement_status = "Use um intervalo maior que 0 e menor que 10000."
        measurement_error = True
        return

    if ship.crashed:
        measurement_status = "Não é possível medir: a sonda colidiu."
        measurement_error = True
        return

    color = (70, 190, 255) if len(measurements) == 0 else (255, 160, 80)

    active_measurement = {
        "points": [(ship.x, ship.y)],
        "duration": duration,
        "color": color
    }

    measurement_elapsed = 0.0
    measurement_remaining = duration

    paused = False
    measurement_status = "Medição em andamento..."
    measurement_error = False


def finish_area_measurement():
    global active_measurement
    global measurement_elapsed, measurement_remaining
    global paused, measurement_status

    if active_measurement is None:
        return

    result = {
        "points": active_measurement["points"][:],
        "duration": active_measurement["duration"],
        "color": active_measurement["color"],
        "area": calculate_swept_area(active_measurement["points"])
    }

    measurements.append(result)

    active_measurement = None
    measurement_elapsed = 0.0
    measurement_remaining = 0.0

    paused = True

    if len(measurements) == 1:
        measurement_status = "Primeira medição concluída. Escolha outra posição orbital."
    else:
        measurement_status = "Comparação concluída."

def draw_area_measurements(camera_x, camera_y):
    areas = measurements[:]

    if active_measurement is not None:
        areas.append(active_measurement)

    for area in areas:
        points = area["points"]

        if len(points) < 2:
            continue

        # O polígono começa no Sol e acompanha a trajetória da sonda.
        polygon = [
            world_to_screen(0, 0, camera_x, camera_y)
        ]

        for x, y in points:
            polygon.append(
                world_to_screen(x, y, camera_x, camera_y)
            )

        # Área preenchida com transparência.
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

        alpha = 45 if area is active_measurement else 65

        pygame.draw.polygon(
            overlay,
            (*area["color"], alpha),
            polygon
        )

        screen.blit(overlay, (0, 0))

        # Contorno do setor.
        pygame.draw.lines(
            screen,
            area["color"],
            False,
            polygon[1:],
            2
        )

        pygame.draw.line(
            screen,
            area["color"],
            polygon[0],
            polygon[1],
            2
        )

        pygame.draw.line(
            screen,
            area["color"],
            polygon[0],
            polygon[-1],
            2
        )

def draw_measurement_interface():
    # Título
    draw_text("MEDIÇÃO DA 2ª LEI DE KEPLER", 20, 137, small=True)
    draw_text(
    "Pause a sonda, escolha o intervalo e pressione MEDIR.",
    20,
    153,
    small=True
    )
    # Campo de intervalo
    input_color = (100, 180, 255) if measurement_input_active else (120, 120, 120)
    
    pygame.draw.rect(
            screen,
            (30, 30, 40),
            measurement_input_rect
        )
    
    pygame.draw.rect(
            screen,
            input_color,
            measurement_input_rect,
            2
        )
    
    draw_text(
            measurement_input_text,
            measurement_input_rect.x + 8,
            measurement_input_rect.y + 5,
            small=True
        )
    
        # Botão principal
    if active_measurement is not None:
            button_text = "MEDINDO..."
            button_color = (90, 90, 90)
    elif len(measurements) >= 2:
            button_text = "LIMPAR MEDIÇÕES"
            button_color = (170, 90, 70)
    elif len(measurements) == 1:
            button_text = "MEDIR SEGUNDO SETOR"
            button_color = (190, 120, 55)
    else:
            button_text = "MEDIR PRIMEIRO SETOR"
            button_color = (50, 120, 180)
    
    pygame.draw.rect(
            screen,
            button_color,
            measurement_button_rect
        )
    
    draw_text(
            button_text,
            measurement_button_rect.x + 8,
            measurement_button_rect.y + 5,
            small=True
        )
    
        # Orientação do intervalo
    draw_text(
            "Intervalo (unidades de tempo)",
            20,
            218,
            small=True
        )
    
        # Estado da medição
    status_color = (255, 100, 100) if measurement_error else (220, 220, 220)
    
    draw_text(
            measurement_status,
            20,
            242,
            small=True,
            color=status_color
        )
    
        # Resultados
    if len(measurements) >= 1:
            draw_text(
                f"A1: {measurements[0]['area']:.3f}",
                20,
                270,
                small=True,
                color=(70, 190, 255)
            )
    
    if len(measurements) >= 2:
            draw_text(
                f"A2: {measurements[1]['area']:.3f}",
                175,
                270,
                small=True,
                color=(255, 160, 80)
            )
    
            a1 = measurements[0]["area"]
            a2 = measurements[1]["area"]
    
            average = (a1 + a2) / 2
    
            if average > 0:
                difference = abs(a1 - a2) / average * 100
                draw_text(
                    f"Diferenca: {difference:.2f}%",
                    20,
                    294,
                    small=True
                )
    
        # Contagem regressiva
    if active_measurement is not None:
            draw_text(
                f"Tempo restante: {measurement_remaining:.2f}",
                20,
                318,
                small=True
            )
    

def register_orbit():
    global third_law_status
    orbit = calculate_orbit(
        initial_radius,
        0,
        0,
        -initial_speed
    )

    if orbit["type"] != "ELIPTICA":
        third_law_status = "A órbita não é elíptica."
        return False

    a = orbit["a"]
    period = orbit["period"]

    orbital_records.append({
        "a": a,
        "period": period,
        "a3": a**3,
        "t2": period**2
    })
    
    third_law_status = f"Órbita registrada! Total: {len(orbital_records)}"

    return True

def draw_third_law_interface():
    draw_text("EXPERIMENTO DA 3ª LEI DE KEPLER", 20, 137, small=True)

    pygame.draw.rect(
        screen,
        (50, 120, 180),
        orbital_record_button_rect,
        border_radius=5
    )

    draw_text(
        "REGISTRAR ÓRBITA",
        orbital_record_button_rect.x + 8,
        orbital_record_button_rect.y + 7,
        small=True
    )

    draw_text("CASAS DECIMAIS:", 250, 187, small=True)

    draw_text(
        "ENTER PARA CONFIRMAR",
        decimal_input_rect.x,
        decimal_input_rect.y + 35,
        small=True
    )

    pygame.draw.rect(
        screen,
        (40, 45, 65),
        decimal_input_rect,
        border_radius=5
    )

    pygame.draw.rect(
        screen,
        (100, 150, 200) if decimal_input_active else (90, 95, 115),
        decimal_input_rect,
        2,
        border_radius=5
    )

    draw_text(
        decimal_input_text,
        decimal_input_rect.x + 8,
        decimal_input_rect.y + 6,
        small=True
    )

    draw_text(
        third_law_status,
        20,
        220,
        small=True
        )

    for i, record in enumerate(orbital_records):
        y = 250 + i * 25

        draw_text(
            f"Orbita {i + 1}: a = {record['a']:.{decimal_places}f}",
            20,
            y,
            small=True
        )

        draw_text(
            f"a³ = {record['a3']:.{decimal_places}f} | T² = {record['t2']:.{decimal_places}f}",
            250,
            y,
            small=True
        )

def draw_mission_guide():
    if not mission_guide_open:
        return

    panel = pygame.Rect(20, 145, 430, 250)

    pygame.draw.rect(
        screen,
        (20, 28, 48),
        panel,
        border_radius=8
    )

    pygame.draw.rect(
        screen,
        (80, 120, 170),
        panel,
        2,
        border_radius=8
    )

    if current_mission == "second_law":
        title = "GUIA — SEGUNDA LEI"
        explanation = (
            "A linha que liga o Sol à sonda varre áreas iguais "
            "em intervalos de tempo iguais. Realize duas medições "
            "com a mesma duração, partindo de posições diferentes "
            "da órbita, e compare as áreas obtidas."
        )

    else:
        title = "GUIA — TERCEIRA LEI"
        explanation = (
            "A terceira lei de Kepler relaciona o período orbital "
            "ao semieixo maior da órbita: T² é proporcional a a³. "
            "Registre órbitas com tamanhos diferentes e compare "
            "os valores de T² e a³."
        )

    draw_text(title, panel.x + 15, panel.y + 15)

    draw_wrapped_text(
        explanation,
        panel.x + 15,
        panel.y + 60,
        panel.width - 30,
        small=True
    )

    button_rect = pygame.Rect(
        panel.right - 125,
        panel.bottom - 45,
        110,
        32
    )

    pygame.draw.rect(
        screen,
        (55, 130, 90),
        button_rect,
        border_radius=5
    )

    draw_text(
        "ENTENDI",
        button_rect.x + 20,
        button_rect.y + 7,
        small=True
    )

    return button_rect

# ESTADO INICIAL

ship = create_ship()
running = True
paused = False
current_mission = None
first_law_step = 0
first_law_answer = None
first_law_feedback = ""
first_law_completed = False
mission_guide_open = False

# LOOP PRINCIPAL
async def main():
    global running, current_mission, geometry_mode, mission_guide_open
    global paused, ship, follow_ship
    global initial_radius, initial_speed, simulation_speed
    global central_mass, current_mu, zoom
    global active_measurement, measurement_elapsed, measurement_remaining
    global measurement_input_active, measurement_input_text
    global measurement_status, measurement_error
    global decimal_input_active, decimal_input_text, decimal_places
    global first_law_step, first_law_answer
    global first_law_feedback, first_law_completed

    print("JOGO INICIADO")

    while running:
        real_dt = clock.tick(FPS) / 1000

        # EVENTOS
        for event in pygame.event.get():
            
            game_event = event

            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                toggle_fullscreen()

            elif current_mission is None:
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    buttons = get_mission_button_rects()

                    for mission_id, rect in buttons.items():
                        if rect.collidepoint(event.pos):
                            current_mission = mission_id

                            if mission_id == "first_law":
                                geometry_mode = True
                                first_law_step = 0
                                first_law_answer = None
                                first_law_feedback = ""
                                first_law_completed = False
                            else:
                                geometry_mode = False
                                mission_guide_open = mission_id in ("second_law", "third_law")
                            break

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and mission_guide_open
            ):
                guide_button = pygame.Rect(
                    325, 350, 110, 32
                )

                if guide_button.collidepoint(event.pos):
                    mission_guide_open = False
            
            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and get_back_button_rect().collidepoint(event.pos)
            ):
                current_mission = None
                geometry_mode = False
                paused = False

                measurements.clear()
                active_measurement = None
                measurement_elapsed = 0.0
                measurement_remaining = 0.0
                measurement_input_active = False
                measurement_status = "Informe o intervalo e inicie a primeira medição."
                measurement_error = False
                measurement_input_text = "1.0"

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and current_mission == "first_law"
                and not first_law_completed
                and (
                    any(
                        pygame.Rect(35, 265 + i * 38, 400, 32).collidepoint(event.pos)
                        for i in range(4)
                    )
                    or (
                        first_law_answer == FIRST_LAW_STEPS[first_law_step]["correct"]
                        and pygame.Rect(325, 495, 110, 32).collidepoint(event.pos)
                    )
                )
            ):
                option_rects, continue_rect = draw_first_law_question()

                if continue_rect and continue_rect.collidepoint(event.pos):
                    advance_first_law_step()

                elif continue_rect is None:
                    for i, option_rect in enumerate(option_rects):
                        if option_rect.collidepoint(event.pos):
                            answer_first_law_question(i)
                            break

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and measurement_input_rect.collidepoint(event.pos)
                and current_mission == "second_law"
            ):
                if active_measurement is None and len(measurements) == 0:
                    measurement_input_active = True

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and measurement_button_rect.collidepoint(event.pos)
                and current_mission == "second_law"
            ):
                measurement_input_active = False

                if active_measurement is None:
                    start_area_measurement()

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and current_mission == "third_law"
                and orbital_record_button_rect.collidepoint(event.pos)
            ):
                register_orbit()

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and current_mission == "third_law"
            ):
                decimal_input_active = decimal_input_rect.collidepoint(event.pos)

            elif any(slider.handle_event(game_event) for slider in sliders):
                continue  

            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
                and reset_button_rect.collidepoint(game_event.pos)
            ):
                reset_settings()

            elif event.type == pygame.MOUSEWHEEL:
                zoom = max(MIN_ZOOM, min(MAX_ZOOM, zoom * 1.15**event.y))
                zoom_slider.value = zoom

            elif event.type == pygame.KEYDOWN:

                if current_mission == "third_law" and decimal_input_active:

                    if event.key == pygame.K_RETURN:
                        if decimal_input_text:
                            decimal_places = min(15, int(decimal_input_text))
                        else:
                            decimal_input_text = str(decimal_places)

                        decimal_input_active = False

                    elif event.key == pygame.K_BACKSPACE:
                        decimal_input_text = decimal_input_text[:-1]

                    elif event.unicode.isdigit() and len(decimal_input_text) < 2:
                        decimal_input_text += event.unicode

                    continue

                if measurement_input_active:
                    if event.key == pygame.K_RETURN:
                        measurement_input_active = False

                    elif event.key == pygame.K_BACKSPACE:
                        measurement_input_text = measurement_input_text[:-1]

                    elif (
                        event.unicode in "0123456789.,"
                        and len(measurement_input_text) < 10
                    ):
                        if event.unicode not in ",." or (
                            "," not in measurement_input_text
                            and "." not in measurement_input_text
                        ):
                            measurement_input_text += event.unicode

                    continue

                if event.key == pygame.K_SPACE:
                    paused = not paused

                elif event.key == pygame.K_r:
                    ship = create_ship()
                    paused = False

                elif event.key in (pygame.K_UP, pygame.K_DOWN):
                    change = 5 if event.key == pygame.K_UP else -5
                    initial_speed = max(0, initial_speed + change)
                    speed_slider.value = initial_speed
                    ship = create_ship()

                elif event.key == pygame.K_f:
                    follow_ship = not follow_ship

                elif event.key == pygame.K_c:
                    follow_ship = False

                elif event.key == pygame.K_g:
                    geometry_mode = not geometry_mode

                elif event.key in (pygame.K_RIGHT, pygame.K_LEFT):
                    factor = 2 if event.key == pygame.K_RIGHT else 0.5
                    simulation_speed = max(
                        MIN_SIMULATION_SPEED,
                        min(MAX_SIMULATION_SPEED, simulation_speed * factor)
                    )
                    simulation_slider.value = simulation_speed

        if current_mission is None:
            draw_mission_menu()
            pygame.display.flip()
            await asyncio.sleep(0)
            continue
        
        # SLIDERS
        mouse_position = pygame.mouse.get_pos()

        mouse_pressed = pygame.mouse.get_pressed()[0]

        for slider in sliders:
            slider.update(mouse_position, mouse_pressed)

        initial_speed = speed_slider.value
        simulation_speed = simulation_slider.value
        zoom = zoom_slider.value

        central_mass = mass_slider.value
        initial_radius = radius_slider.value

        current_mu = G * central_mass

        ship.mu = current_mu

        # CÂMERA
        if follow_ship:
            camera_x, camera_y = ship.x, ship.y
        else:
            camera_x = camera_y = 0

        # ATUALIZAÇÃO FÍSICA
        if not paused and not ship.crashed:
            dt = real_dt * simulation_speed

            steps = max(1, math.ceil(dt / MAX_PHYSICS_STEP))
            sub_dt = dt / steps

            for _ in range(steps):
                step_dt = sub_dt

                if active_measurement is not None:
                    step_dt = min(step_dt, measurement_remaining)

                ship.update(step_dt)

                if active_measurement is not None:
                    active_measurement["points"].append(
                        (ship.x, ship.y)
                    )

                    measurement_elapsed += step_dt
                    measurement_remaining = max(
                        0.0,
                        measurement_remaining - step_dt
                    )

                    if ship.crashed:
                        active_measurement = None
                        measurement_elapsed = 0.0
                        measurement_remaining = 0.0
                        paused = True

                        measurement_status = (
                            "Medição interrompida: a sonda colidiu com o Sol."
                        )
                        measurement_error = True
                        break

                    if measurement_remaining <= 1e-10:
                        finish_area_measurement()
                        break

        # CÁLCULOS ORBITAIS
        orbit = calculate_orbit(initial_radius, 0, 0, -initial_speed)
        predicted_orbit = generate_predicted_orbit(orbit)

        # FUNDO
        screen.fill(BACKGROUND)
        draw_area_measurements(camera_x, camera_y)

        # ÓRBITA PREVISTA
        draw_dashed_orbit(predicted_orbit, camera_x, camera_y)

        # SOL
        star_position = world_to_screen(0, 0, camera_x, camera_y)
        star_radius = max(3, int(SUN_RADIUS * zoom))
        pygame.draw.circle(screen, STAR_COLOR, star_position, star_radius)

        # FOCOS: sempre visíveis
        draw_foci(orbit, camera_x, camera_y)

        # GEOMETRIA ADICIONAL
        if geometry_mode:
            draw_ellipse_geometry(
            orbit,
            camera_x,
            camera_y
            )

        # TRAJETÓRIA REAL
        if len(ship.trail) > 1:
            screen_points = [
                world_to_screen(x, y, camera_x, camera_y)
                for x, y in ship.trail
            ]
            pygame.draw.lines(
                screen, ORBIT_COLOR, False, screen_points,
                max(1, int(2 * zoom))
            )

        # SONDA
        ship_position = world_to_screen(ship.x, ship.y, camera_x, camera_y)
        pygame.draw.circle(screen, SHIP_COLOR, ship_position, max(3, int(7 * zoom)))

        # INFORMAÇÕES
        draw_text("MISSAO KEPLER", 20, 20)
        draw_text(f"Tipo: {orbit['type']}", 20, 55)
        draw_text(f"Excentricidade: {orbit['eccentricity']:.3f}", 20, 85)

        if geometry_mode:
            draw_text(
            "MODO GEOMETRIA: ATIVO",
            WIDTH - 250,
            55,
            (120, 220, 190),
            small=True
            )
        else:
            draw_text(
            "MODO GEOMETRIA: INATIVO",
            WIDTH - 250,
            55,
            (120, 140, 160),
            small=True
            )

        if orbit["period"] is not None:
            draw_text(f"Periodo estimado: {orbit['period']:.2f} s", 20, 115)
        else:
            draw_text("Periodo: nao possui orbita fechada", 20, 115)

        if ship.crashed:
            draw_text("COLISAO COM O SOL", WIDTH // 2 - 130, 20, WARNING_COLOR)

        # CONTROLES
        draw_text("UP/DOWN: velocidade inicial", 20, 500, small=True)
        draw_text("LEFT/RIGHT: velocidade da simulacao", 20, 525, small=True)
        draw_text("RODINHA: zoom", 20, 550, small=True)
        draw_text("F: acompanhar sonda | C: Sol", 20, 575, small=True)
        draw_text("R: reiniciar | ESPACO: pausar", 20, 600, small=True)
        draw_text("G: modo geometria", 20, 625, small=True)

        if paused:
            draw_text("PAUSADO", WIDTH - 130, 20)

        # SLIDERS
        for slider in sliders:
            slider.draw(screen, small_font)

        # BOTÃO DE RESTAURAÇÃO
        pygame.draw.rect(
            screen, (35, 45, 70),
            reset_button_rect, border_radius=5
        )

        pygame.draw.rect(
            screen, (120, 190, 255),
            reset_button_rect, 1, border_radius=5
        )

        button_text = small_font.render(
            "RESTAURAR PADRÕES", True, TEXT_COLOR
        )

        button_text_rect = button_text.get_rect(
            center=reset_button_rect.center
        )

        screen.blit(button_text, button_text_rect)

        if current_mission == "second_law":
            draw_measurement_interface()

        if current_mission == "third_law":
            draw_third_law_interface()

        if current_mission == "first_law":
            draw_first_law_question()

        if current_mission is not None:
            draw_back_button()

        draw_mission_guide()

        pygame.display.flip()
        await asyncio.sleep(0)
asyncio.run(main())